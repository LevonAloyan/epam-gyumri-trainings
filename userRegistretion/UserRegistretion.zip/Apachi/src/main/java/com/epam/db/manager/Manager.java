package com.epam.db.manager;

import java.util.List;

public interface Manager <T> {
    List<T> getAll();

    public T create (T obj);

   public boolean existEmailAndPass(String email, String pass);
    public T getByEmailAndPass ( String email, String pass);
}
