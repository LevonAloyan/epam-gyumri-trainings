package model;

import java.io.Serializable;

public abstract class Entity implements Serializable, Cloneable {
}
