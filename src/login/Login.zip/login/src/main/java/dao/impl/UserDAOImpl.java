package dao.impl;

import config.DBConnectionProvider;
import dao.UserDAO;
import model.User;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UserDAOImpl implements UserDAO {

    private Connection connection;

    private PreparedStatement findAll;
    private PreparedStatement findByEmail;
    private PreparedStatement findByEmailAndPassword;
    private PreparedStatement create;
    private PreparedStatement update;
    private PreparedStatement delete;

    public UserDAOImpl() {
        try {
            connection = DBConnectionProvider.getInstance().getConnection();
            findAll = connection.prepareStatement("SELECT * FROM user ORDER BY name, last_name");
            findByEmail = connection.prepareStatement("SELECT * FROM user WHERE email = ?");
            findByEmailAndPassword = connection.prepareStatement("SELECT * FROM user WHERE email = ? and password = ?");
            create = connection.prepareStatement("INSERT INTO user (name, last_name, age, email, password)" +
                    "VALUES(?,?,?,?,?)");
            update = connection.prepareStatement("UPDATE user Set password = ? WHERE email = ?");
            delete = connection.prepareStatement("Delete FROM user WHERE id =? ");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<User> findAll() {
        try (ResultSet resultSet = findAll.executeQuery()) {
            List<User> results = new ArrayList<>();
            while (resultSet.next()) {
                results.add(new User(
                        resultSet.getInt("Id"),
                        resultSet.getString("Name"),
                        resultSet.getString("Last_Name"),
                        resultSet.getString("Age"),
                        resultSet.getString("Email"),
                        resultSet.getNString("Password")));
            }
            return results;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
        return null;
    }

    @Override
    public User findByEmail(String email) {
        try {
            findByEmail.setString(1, email);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            return null;
        }
        try (ResultSet resultSet = findByEmail.executeQuery()) {
            User user = new User();
            while (resultSet.next()) {
                user.setId(resultSet.getInt("Id"));
                user.setName(resultSet.getString("Name"));
                user.setLastName(resultSet.getString("Last_Name"));
                user.setAge(resultSet.getString("Age"));
                user.setEmail(resultSet.getString("Email"));
                user.setPassword(resultSet.getNString("Password"));
            }
            return user;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            return null;
        }
    }
    @Override
    public User findByEmailAndPassword(String email, String password) {
        try {
            findByEmailAndPassword.setString(1, email);
            findByEmailAndPassword.setString(2, password);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            return null;
        }
        try (ResultSet resultSet = findByEmailAndPassword.executeQuery()) {
            User user = new User();
            while (resultSet.next()) {
                user.setId(resultSet.getInt("Id"));
                user.setName(resultSet.getString("Name"));
                user.setLastName(resultSet.getString("Last_Name"));
                user.setAge(resultSet.getString("Age"));
                user.setEmail(resultSet.getString("Email"));
                user.setPassword(resultSet.getNString("Password"));
            }
            return user;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            return null;
        }
    }

    @Override
    public boolean create(User user) {
        try {
            create.setString(1, user.getName());
            create.setString(2, user.getLastName());
            create.setString(3, user.getAge());
            create.setString(4, user.getEmail());
            create.setString(5, user.getPassword());
            create.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public User update(User user, String password) {
        try {
            update.setString(1, password);
            update.setString(2, user.getEmail());
            update.executeUpdate();
            return findByEmail(user.getEmail());
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public boolean delete(Integer id) {
        try {
            delete.setInt(1, id);
            delete.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

}
