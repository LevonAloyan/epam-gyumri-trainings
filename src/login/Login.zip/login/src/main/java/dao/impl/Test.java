package dao.impl;

public class Test {
    public static void main(String[] args) {
        UserDAOImpl user = new UserDAOImpl();
//        System.out.println(user.findByEmail("armzak91@mail.ru"));
//        System.out.println(user.findAll());
        //  User newUser = new User("Poghos","Poghosyan","20","poghos@mail.ru","pass");
          // System.out.println(user.create(newUser));
     //   System.out.println(user.delete(1));
        //   System.out.println(user.update(newUser, "password"));
     //   User user1 = user.findByEmailAndPassword("poghos@mail.ru", "pass");
       // System.out.println(user1);
    }
}
