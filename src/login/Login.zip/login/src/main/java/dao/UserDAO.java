package dao;

import model.User;

public interface UserDAO extends DAO<Integer,String, User>{
    User findByEmail(String email);
    User findByEmailAndPassword(String email,String password);
    User update(User user, String password);
}
