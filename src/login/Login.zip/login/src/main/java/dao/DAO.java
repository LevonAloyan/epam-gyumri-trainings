package dao;

import model.Entity;

import java.util.List;

public interface DAO<K,S,T extends Entity> {
    boolean create(T t);
    List<T> findAll();
    T update (T t,S s);
    boolean delete(K id);

}
