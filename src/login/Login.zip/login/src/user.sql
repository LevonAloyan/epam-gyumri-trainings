CREATE DATABASE user;

USE user;

CREATE TABLE user(  
  id          INT NOT NULL AUTO_INCREMENT,  
  name        VARCHAR(255), 
  last_name   VARCHAR(255),
  age	      VARCHAR(255),
  email       VARCHAR(255) UNIQUE,
  password    VARCHAR(255), 
  CONSTRAINT pk_user PRIMARY KEY (id)     
);
